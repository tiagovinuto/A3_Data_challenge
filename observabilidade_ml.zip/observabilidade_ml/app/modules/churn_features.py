
from pydantic import BaseModel

class Churn_features(BaseModel):
      
    gender:float
    SeniorCitizen:float
    Partner:float
    Dependents:float
    tenure:float
    PhoneService:float
    MultipleLines:float
    InternetService:float
    OnlineSecurity:float
    OnlineBackup:float
    DeviceProtection:float
    TechSupport:float
    StreamingTV:float
    StreamingMovies:float
    Contract:float
    PaperlessBilling:float
    PaymentMethod:float
    MonthlyCharges:float
    TotalCharges:float