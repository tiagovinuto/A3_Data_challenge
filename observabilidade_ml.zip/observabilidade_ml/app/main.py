import joblib
import pandas as pd
from prometheus_fastapi_instrumentator import Instrumentator
from prometheus_client import Histogram, Counter
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from modules.churn_features import Churn_features
import time

import sys
sys.path.append("../")

modelo_bank = open("models/modelo_logistc_regression_a.pkl", "rb")
classificador = joblib.load(modelo_bank)

app = FastAPI()

model_prediction_latency = Histogram('model_prediction_latency_seconds', 'Model Prediction Latency (seconds)')
api_prediction_requests_total = Counter('api_prediction_requests_total', 'Total Prediction Requests')
api_prediction_request_errors_total = Counter('api_prediction_request_errors_total', 'API Prediction Request Errors')

@app.get('/')
def home():
    return "Predição de Churn"

@app.post('/predict/') #response_model=Banck_features
def predict_banck_features(data:Churn_features):

    start_time = time.time()  # Start time for latency measurement

    try:
        features = data.model_dump()
        current_data=pd.DataFrame([list(features.values())])
        current_data['prediction']=classificador.predict(current_data)[0]
    except Exception as e:
        api_prediction_request_errors_total.inc()
        raise e

    prediction_time = time.time() - start_time
    model_prediction_latency.observe(prediction_time)
    
    return {
        'prediction': current_data['prediction'].tolist()[0]
    }

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


Instrumentator().instrument(app).expose(app)

